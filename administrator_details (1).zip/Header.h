#pragma once
#pragma warning(disable : 4996)
#include <iostream>
#include <sstream>
#include <fstream>
#include <string>
#include <regex> 
#include<chrono>
#include<thread>
#include <iomanip>
#include <conio.h>
#include <exception>	
#include <windows.h>

using namespace std;

regex valid_email("[a-zA-Z_0-9._]+@[a-zA-Z0-9]+.[a-zA-Z]+");
regex valid_contact_num("(03)[0-9]{2}-[0-9]{7}");
regex valid_user_num("[0-9]{5}");
regex valid_cnic("[0-9]{5}-[0-9]{7}-[0-9]");
regex valid_name("[A-Za-z]+");

regex upper_case("[A-Z]+");
regex lower_case("[a-z]+");
regex number{ "[0-9]+" };

HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
string FILE_PATH = "";


//---------EXCEPTIONS---------------
bool is_valid_username(string username)
{
	string modes[5] = { "SA", "AD", "DC", "FD", "GO" };
	string mode = username.substr(0, 2);
	string num = username.substr(2);

	bool un_mode = false, un_num = false;

	for (int i = 0; i < 5; i++)
	{
		if (mode == modes[i])
		{
			un_mode = true;
		}
	}

	if (regex_match(num, valid_user_num))
	{
		un_num = true;
	}

	if (un_num && un_mode)
	{
		return true;
	}
	else
	{
		return false;
	}
}

bool is_valid_password(string pass)
{
	int conditions = 0;

	if (pass.size() >= 8)
	{
		conditions += 1;
	}

	conditions += regex_search(pass, upper_case) + regex_search(pass, lower_case) + regex_search(pass, number);

	if (conditions == 4)
	{
		return true;
	}
	else
	{
		return false;
	}
}

bool is_valid_name(string name)
{
	return regex_match(name, valid_name);
}

bool is_valid_email(string email)
{
	return regex_match(email, valid_email);
}

bool is_valid_contact(string num)
{
	return regex_match(num, valid_contact_num);
}

bool is_valid_cnic(string cnic)
{
	return regex_match(cnic, valid_cnic);
}


class username_exists : public exception
{

public:
	const char* what() const
	{
		return ("The entered username already exists.");
	}
};
class invalid_username : public exception
{

public:
	const char* what() const
	{
		return ("The entered username is not valid.");
	}
};
class invalid_password : public exception
{

public:
	const char* what() const
	{
		return ("The entered password is not valid.");
	}
};
class wrong_password : public exception
{

public:
	const char* what() const
	{
		return ("The entered password is incorrect.");
	}
};

class unregistered_username : public exception
{

public:
	const char* what() const
	{
		return ("The entered username is not registered.");
	}
};
//-------------------------------------------------------------

void print_error(string output)
{
	SetConsoleTextAttribute(h, 252);
	cout << output;
	SetConsoleTextAttribute(h, 240);
}

template<typename T>
void expand(T*& ptr, int& size)
{
	if (size != 0)
	{
		T* temp = new T[size];
		for (int i = 0; i < size; i++)
		{
			temp[i] = ptr[i];
		}

		size++;

		delete[] ptr;
		ptr = new T[size];

		for (int i = 0; i < size - 1; i++)
		{
			ptr[i] = temp[i];
		}
	}
	else
	{
		size++;
		ptr = new T[size];
	}

}

template <typename T>
void del(T*& ptr, int size, int index)
{
	T* temp = new T[size - 1];
	int count = 0;

	for (int i = 0; i < size; i++)
	{
		if (i != index)
		{
			temp[count++] = ptr[i];
		}
	}

	delete[] ptr;

	ptr = new T[size - 1];

	for (int i = 0; i < size - 1; i++)
	{
		ptr[i] = temp[i];
	}
}

template <typename T>
T safe_input()
{
	T temp;
	bool is_input = false;

	while (!is_input)
	{
		try
		{
			cin >> temp;

			if (!cin)
				throw 0;

			is_input = true;


		}
		catch (...)
		{

			cin.clear(); //clear bad input flag
			//cin.ignore(std::numeric_limits<streamsize>::max(), '\n'); //discard input

			print_error("\n[!] Invalid Input !!\n");
			cout << "\nEnter again: ";
		}
	}

	return temp;
}

string encrypt(string username, string pass)
{
	int key = 0;

	// calculates the key used for encryption
	for (int i = 2; i < 7; i++)
	{
		key += username[i] - 48; // converting char number into integar
	}

	//cout << "key " << key << endl;

	// coverts the entered password into encrypted one to compare with the original
	for (int i = 0; i < pass.size(); i++)
	{

		pass[i] += key;
		//cout << int(pass[i]) << endl;

		if (int(pass[i]) < 0) // makes sure ASCII doesn't go in negative value
		{
			pass[i] *= -1;
		}

		if (int(pass[i]) == 127) // 127 is the delete character; causes problems in comparing the passwords
		{
			pass[i] -= 1;
		}
		//cout << int(pass[i]) << endl;
	}

	return pass;
}

void print_spaces(int space = 38)
{
	cout << "\n" << setfill(' ') << setw(space) << "";
}


class Product
{
public:
	string category;
	string ProductName;
	string ProductQuantity;

	//taken from file

	Product() {}
	void ProductInput();
	void ProductOutput();

	string file_details();

	bool compare_ProductName(string n);

	void load_data(string cname, string cate, string quantity);



};


class person
{
protected:
	string username, pass;
	string firstname, lastname, email, CNIC, contactNumber;

public:
	person();
	person(string un, string fn, string ln, string em, string cn, string No);
	void input();
	void output();

	bool compare_username(string un);

	virtual string file_details();

	string file_logindetails();

	void load_person_data(string un, string fn, string ln, string em, string cn, string No);


	virtual void input_login_details() = 0; // input username and password
};



class Shop_Keeper : public person
{
public:
	static int products_count;
	static Product* products_list;

	Shop_Keeper();
	Shop_Keeper(string un, string fn, string ln, string em, string cn, string No);

	void KeeperOutput();

	void add_product();
	void delete_product();
	void display_product();


	string file_details();

	void load_Keeper_data(string un, string fn, string ln, string em, string cn, string No, string tprice);
	void input_login_details();


	static int find_product_index(string n);

};

int Shop_Keeper::products_count = 0;

Product* Shop_Keeper::products_list = nullptr;

class Customer : public person
{
public:
	static int companies_count;

	Customer() {}
	Customer(string un, string fn, string ln, string em, string cn, string No);
	void customerOutput();

	/* void add_company();
	 void delete_company();
	 void display_company();*/
	void load_customer_data(string un, string fn, string ln, string em, string cn, string No, string tprice);
	void input_login_details();


	///* static int find_company_index(string n)
	// {
	//     for (int i = 0; i < companies_count; i++)
	//     {
	//         if (companies_list[i].compare_companyName(n))
	//         {
	//             return i;
	//         }
	//     }

	//     return -1;
	// }*/


};

int Customer::companies_count = 0;

class Administrator : public person
{
public:
	static Administrator* self_instance;

	static int Keeper_count, customer_count, products_count;

	static Shop_Keeper* Keeper_list;
	static Customer* customer_list;
	static Product* products_list;

	Administrator(string un, string fn, string ln, string em, string cn, string No);

	static int find_product_index(string n);
	static int find_Keeper_index(string un);
	static int find_customer_index(string un);


	static Administrator* getInstance(string un, string fn, string ln, string em, string cn, string No);


	static Shop_Keeper* Keeper_obj(string un);
	static Customer* customer_obj(string un);

	void create_customer();
	void delete_customer();
	void update_customer();
	void display_customer();

	static void store_customer();

	void create_keeper();
	void delete_keeper();
	void update_keeper();
	void display_keeper();

	static void store_keepers();

	void add_product_admin();

	void delete_product_admin();

	void display_product_admin();


	void input_login_details();

};

int Administrator::Keeper_count = 0;
int Administrator::products_count = 0;
int Administrator::customer_count = 0;


Shop_Keeper* Administrator::Keeper_list = nullptr;
Customer* Administrator::customer_list = nullptr;
Product* Administrator::products_list = nullptr;
class Filing
{
public:
	static bool find_admin(string username);
	static bool is_valid_login_admin(string username, string pass);
	static Administrator* login_admin(string username);

	static bool find_keeper(string username);
	static bool is_valid_login_keeper(string username, string pass);

	static void initiate_all_keeper(Shop_Keeper*& keeper_list, int& keeper_count);

	static void add_new_keeper(Shop_Keeper* obj);
	static void store_deleted_keepers(string username, Shop_Keeper* arr, int size);
	static void store_updated_keepers(string username, Shop_Keeper* arr, int size);

	static bool find_customer(string username);
	static bool is_valid_login_customer(string username, string pass);

	static void initiate_all_customer(Customer*& customer_list, int& customer_count);

	static void add_new_customer(Customer* obj);
	static void store_deleted_customers(string username, Customer* arr, int size);
	static void store_updated_customers(string username, Customer* arr, int size);

	static void initiate_all_Products(Product*& products_list, int& products_count);
	static void add_new_products(Product* obj);
	static void store_Products(Product* arr, int size);
};
//------------------------ PERSON DEFINATIONS------------------------------------------------------------------

person::person()
{
	username = pass = firstname = lastname = email = contactNumber = CNIC = " ";

}
person::person(string un, string fn, string ln, string em, string cn, string No) :username(un), firstname(fn), lastname(ln), email(em), CNIC(cn), contactNumber(No) {}
void person::input()
{

	cout << "Enter First Name: ";
	do
	{
		cin >> firstname;
		if (!is_valid_name(firstname))
		{
			print_error("\n[!] ERROR: The name should only have alphabets.\n\n");
			cout << "Enter again: ";
		}
	} while (!is_valid_name(firstname));

	cout << "Enter last Name: ";
	do
	{
		cin >> lastname;
		if (!is_valid_name(lastname))
		{
			print_error("\n[!] ERROR: The name should only have alphabets.\n\n");
			cout << "Enter again: ";
		}
	} while (!is_valid_name(lastname));

	cout << "Enter Email Address: ";
	do
	{
		cin >> email;
		if (!is_valid_email(email))
		{
			print_error("\n[!] ERROR: The email entered in not valid.\n\n");
			cout << "Enter again: ";
		}
	} while (!is_valid_email(email));

	cout << "Enter CNIC: ";

	do
	{
		cin >> CNIC;
		if (!is_valid_cnic(CNIC))
		{
			print_error("\n[!] ERROR: The CNIC entered in not valid.\n\n");
			cout << "Enter again: ";
		}
	} while (!is_valid_cnic(CNIC));

	cout << "Enter Contact Number: ";
	do
	{
		cin >> contactNumber;
		if (!is_valid_contact(contactNumber))
		{
			print_error("\n[!] ERROR: The phone number entered in not valid.\n\n");
			cout << "Enter again: ";
		}
	} while (!is_valid_contact(contactNumber));



}
void person::output()
{
	cout << "First Name: " << firstname << endl;
	cout << "last Name: " << lastname << endl;
	cout << "Email Address: " << email << endl;
	cout << "Contact Number: " << contactNumber << endl;
	cout << "CNIC: " << CNIC << endl;
}
bool person::compare_username(string un)
{
	if (username == un)
	{
		return true;
	}
	else
	{
		return false;
	}
}
string person::file_details()
{
	return  username + "," + firstname + "," + lastname + "," + email + "," + CNIC + "," + contactNumber + ",";
}
string person::file_logindetails()
{
	return username + " " + pass + "\n";
}
void person::load_person_data(string un, string fn, string ln, string em, string cn, string No)
{
	username = un;
	firstname = fn;
	lastname = ln;
	email = em;
	CNIC = cn;
	contactNumber = No;
}
//----------------------------------------------------------------------------------------------------------------

Administrator::Administrator(string un, string fn, string ln, string em, string cn, string No) : person(un, fn, ln, em, cn, No)
{
	// read admin, fdo, doctor, government officials from file
	Keeper_count = products_count = customer_count = 0;


	Filing::initiate_all_keeper(Keeper_list, Keeper_count);
	Filing::initiate_all_customer(customer_list, customer_count);
	Filing::initiate_all_Products(products_list, products_count);
}
Administrator* Administrator::getInstance(string un, string fn, string ln, string em, string cn, string No)
{
	if (self_instance == nullptr)
		self_instance = new Administrator(un, fn, ln, em, cn, No);
	return self_instance;
}
int Administrator::find_Keeper_index(string un)
{
	for (int i = 0; i < Keeper_count; i++)
	{
		if (Keeper_list[i].compare_username(un))
		{
			return i;
		}
	}

	return -1;
}
int Administrator::find_customer_index(string un)
{
	for (int i = 0; i < customer_count; i++)
	{
		if (customer_list[i].compare_username(un))
		{
			return i;
		}
	}

	return -1;
}

void Administrator::create_customer()
{

	expand<Customer>(customer_list, customer_count);

	customer_list[customer_count - 1].input_login_details();
	customer_list[customer_count - 1].input();

	Filing::add_new_customer(&customer_list[customer_count - 1]);
}
void Administrator::delete_customer()
{
	if (customer_count > 0)
	{
		int i;
		string un;
		cout << "Enter the username of admin: ";
		cin >> un;

		i = find_customer_index(un);

		if (i != -1)
		{
			del<Customer>(customer_list, customer_count, i);
			customer_count--;
			Filing::store_deleted_customers(un, customer_list, customer_count);
		}
		else
		{
			print_error("[!] ERROR: The entered username doesn't exists.");
		}
	}
	else
	{
		print_error("\n\n[!]ERROR: There is no admin to delete.\n\n");
	}
}
void Administrator::update_customer()
{
	if (customer_count > 0)
	{
		int i;
		string un;
		cout << "Enter the username of admin: ";
		cin >> un;

		i = find_customer_index(un);

		if (i != -1)
		{
			customer_list[i].input_login_details();
			customer_list[i].input();

			Filing::store_updated_customers(un, customer_list, customer_count);
		}
	}
	else
	{
		print_error("\n\n[!]ERROR: There is no admin to update.\n\n");
	}

}
void Administrator::display_customer()
{

	for (int i = 0; i < customer_count; i++)
	{
		customer_list[i].customerOutput();
		cout << "\n";
	}
}

void Administrator::store_customer()
{
	Filing::store_updated_customers("", customer_list, customer_count);
}

void Administrator::create_keeper()
{

	expand<Shop_Keeper>(Keeper_list, Keeper_count);

	Keeper_list[Keeper_count - 1].input_login_details();
	Keeper_list[Keeper_count - 1].input();

	Filing::add_new_keeper(&Keeper_list[Keeper_count - 1]);
}
void Administrator::delete_keeper()
{
	if (Keeper_count > 0)
	{
		int i;
		string un;
		cout << "Enter the username of admin: ";
		cin >> un;

		i = find_Keeper_index(un);

		if (i != -1)
		{
			del<Shop_Keeper>(Keeper_list, Keeper_count, i);
			Keeper_count--;
			Filing::store_deleted_keepers(un, Keeper_list, Keeper_count);
		}
		else
		{
			print_error("[!] ERROR: The entered username doesn't exists.");
		}
	}
	else
	{
		print_error("\n\n[!]ERROR: There is no admin to delete.\n\n");
	}
}
void Administrator::update_keeper()
{
	if (Keeper_count > 0)
	{
		int i;
		string un;
		cout << "Enter the username of admin: ";
		cin >> un;

		i = find_Keeper_index(un);

		if (i != -1)
		{
			Keeper_list[i].input_login_details();
			Keeper_list[i].input();

			Filing::store_updated_keepers(un, Keeper_list, Keeper_count);
		}
	}
	else
	{
		print_error("\n\n[!]ERROR: There is no admin to update.\n\n");
	}

}
void Administrator::display_keeper()
{

	for (int i = 0; i < Keeper_count; i++)
	{
		Keeper_list[i].KeeperOutput();
		cout << "\n";
	}
}

void Administrator::store_keepers()
{
	Filing::store_updated_keepers("", Keeper_list, Keeper_count);
}
void Administrator::input_login_details() {}

Administrator* Administrator::self_instance = nullptr; // initialization

void Administrator::add_product_admin()
{
	expand<Product>(products_list, products_count);

	products_list[products_count - 1].ProductInput();

	Filing::add_new_products(&products_list[products_count - 1]);
}

void Administrator::delete_product_admin()
{
	if (products_count > 0)
	{
		int i;
		string n;
		cout << "Enter the name of company: ";
		cin >> n;

		i = find_product_index(n);

		if (i != -1)
		{
			del<Product>(products_list, products_count, i);
			products_count--;
			Filing::store_Products(products_list, products_count);
		}
		else
		{
			print_error("[!] ERROR: The entered name doesn't exists.");
		}
	}
	else
	{
		print_error("\n\n[!]ERROR: There is no company to delete.\n\n");
	}
}

void Administrator::display_product_admin()
{

	for (int i = 0; i < products_count; i++)
	{
		cout << "\n";
		products_list[i].ProductOutput();
	}
}

int Administrator::find_product_index(string n)
{
	for (int i = 0; i < products_count; i++)
	{
		if (products_list[i].compare_ProductName(n))
		{
			return i;
		}
	}

	return -1;
}

Shop_Keeper* Administrator::Keeper_obj(string un)
{
	int i = find_Keeper_index(un);
	if (i != -1)
	{
		return &Keeper_list[i];
	}

}

Customer* Administrator::customer_obj(string un)
{
	int i = find_customer_index(un);
	if (i != -1)
	{
		return &customer_list[i];
	}

}

//------------------------ SHOPKEEPER DEFINATIONS------------------------------------------------------------------

Shop_Keeper::Shop_Keeper()
{
	if (products_list == nullptr)
	{
		cout << "ADMIN CONSTRUCTOR" << endl;
		products_count = 0;
		Filing::initiate_all_Products(products_list, products_count);

	}

}

void Shop_Keeper::KeeperOutput()
{
	output();

}
Shop_Keeper::Shop_Keeper(string un, string fn, string ln, string em, string cn, string No) : person(un, fn, ln, em, cn, No)
{

}

void Shop_Keeper::input_login_details()
{
	string un, un_num, p;
	bool correct_input = false;

	while (!correct_input)
	{
		try
		{
			un = "SK";
			cout << "Enter the username: SK";
			cin >> un_num;

			if (!regex_match(un_num, valid_user_num))
			{
				throw invalid_username();
			}

			un += un_num; // concats the digits with "AD"

			if (Filing::find_keeper(un))
			{
				throw username_exists();
			}

			cout << "\nEnter the password";
			cin >> p;

			if (!is_valid_password(p))
			{
				throw invalid_password();
			}

			correct_input = true;
		}
		catch (const exception& e)
		{
			SetConsoleTextAttribute(h, 252);
			print_spaces();
			cout << "[!] Exception: " << e.what() << endl;
			SetConsoleTextAttribute(h, 240);
		}
	}

	username = un;
	pass = encrypt(un, p);


}

void Shop_Keeper::add_product()
{
	expand<Product>(products_list, products_count);

	products_list[products_count - 1].ProductInput();

	Filing::add_new_products(&products_list[products_count - 1]);
}

void Shop_Keeper::delete_product()
{
	if (products_count > 0)
	{
		int i;
		string n;
		cout << "Enter the name of company: ";
		cin >> n;

		i = find_product_index(n);

		if (i != -1)
		{
			del<Product>(products_list, products_count, i);
			products_count--;
			Filing::store_Products(products_list, products_count);
		}
		else
		{
			print_error("[!] ERROR: The entered name doesn't exists.");
		}
	}
	else
	{
		print_error("\n\n[!]ERROR: There is no company to delete.\n\n");
	}
}

void Shop_Keeper::display_product()
{

	for (int i = 0; i < products_count; i++)
	{
		cout << "\n";
		products_list[i].ProductOutput();
	}
}

string Shop_Keeper::file_details()
{
	return person::file_details() + ",\n";
}

void Shop_Keeper::load_Keeper_data(string un, string fn, string ln, string em, string cn, string No, string tprice)
{
	load_person_data(un, fn, ln, em, cn, No);

}

int Shop_Keeper::find_product_index(string n)
{
	for (int i = 0; i < products_count; i++)
	{
		if (products_list[i].compare_ProductName(n))
		{
			return i;
		}
	}

	return -1;
}

//------------------------ FILING DEFINATIONS------------------------------------------------------------------
bool Filing::find_admin(string username)
{
	ifstream login_file(FILE_PATH + "administrator_login_details.txt");
	string o_username;

	login_file >> o_username; // reads original username from the file

	cout << o_username << endl;
	if (username == o_username)
	{
		return true;
	}
	else
	{
		return false;
	}
}
bool Filing::is_valid_login_admin(string username, string pass)
{
	ifstream login_file(FILE_PATH + "administrator_login_details.txt");
	string o_username, o_pass;
	int key = 0;

	login_file >> o_username >> o_pass; // reads original username and password from the file

	pass = encrypt(username, pass);

	if (username == o_username && pass == o_pass)
	{
		return true;
	}
	else
	{
		return false;
	}

}
Administrator* Filing::login_admin(string username)
{
	ifstream details_file(FILE_PATH + "administrator_details.csv");
	int count = 0;
	string line, word;
	string details[6];
	//string o_username, fn, ln, em, cn, No;

	getline(details_file, line);
	stringstream str(line);

	while (getline(str, word, ','))
	{
		details[count++] = word;
	}

	if (details[0] == username)
	{
		return Administrator::getInstance(details[0], details[1], details[2], details[3], details[4], details[5]);
	}
}

bool Filing::find_keeper(string username)
{
	ifstream login_file(FILE_PATH + "ShopKeeper_login_details.txt");

	bool found = false;
	string o_username, o_pass;

	// reads original username from the file
	while (!login_file.eof())
	{
		login_file >> o_username >> o_pass;
		if (username == o_username)
		{
			found = true;
			break;
		}

	}
	login_file.close();

	return found;
}
bool Filing::is_valid_login_keeper(string username, string pass)
{
	ifstream login_file(FILE_PATH + "ShopKeeper_login_details.txt");

	bool logined = false;
	string o_username, o_pass;

	// reads original username from the file
	while (!login_file.eof())
	{
		login_file >> o_username >> o_pass;
		if (username == o_username)
		{
			pass = encrypt(username, pass);

			if (pass == o_pass)
			{
				logined = true;
				break;
			}
		}

	}
	login_file.close();

	return logined;
}

void Filing::initiate_all_keeper(Shop_Keeper*& keeper_list, int& keeper_count)
{
	ifstream details_file(FILE_PATH + "ShopKeeper_details.csv");
	int count = 0;
	string line, word;
	string details[7];
	//string o_username, fn, ln, em, cn, No, tprice;

	while (getline(details_file, line))
	{
		count = 0;
		stringstream str(line);

		while (getline(str, word, ','))
		{
			details[count++] = word;
		}
		//cout << details[0] << endl;
		//cout << admin_count << endl;
		expand<Shop_Keeper>(keeper_list, keeper_count);

		keeper_list[keeper_count - 1].load_Keeper_data(details[0], details[1], details[2], details[3], details[4], details[5], details[6]);
	}

}

void Filing::add_new_keeper(Shop_Keeper* obj)
{
	ofstream details_file(FILE_PATH + "ShopKeeper_details.csv", ios::app);
	ofstream login_file(FILE_PATH + "ShopKeeper_login_details.txt", ios::app);

	if (!details_file || !login_file)
	{
		//print_error("\n\nERROR IN OPENING THE FILE: admin_details.csv or admin_login_details.txt\n\n");
	}
	else
	{
		details_file << obj->file_details();
		login_file << obj->file_logindetails();

		details_file.close();
		login_file.close();
	}
}
void Filing::store_deleted_keepers(string username, Shop_Keeper* arr, int size)
{
	ofstream details_file(FILE_PATH + "ShopKeeper_details.csv");


	if (!details_file)
	{
		print_error("\n\nERROR IN OPENING THE FILE: admin_details.csv\n\n");
	}
	else
	{
		for (int i = 0; i < size; i++)
		{
			details_file << arr[i].file_details();
		}

		details_file.close();
	}

	vector<string> o_username, o_pass;
	string un, pass;
	int count = 0;;

	ifstream login_input_file(FILE_PATH + "ShopKeeper_login_details.txt");

	while (!login_input_file.eof())
	{
		login_input_file >> un >> pass;
		o_username.push_back(un);
		o_pass.push_back(pass);
		count++;
	}
	login_input_file.close();

	ofstream login_output_file(FILE_PATH + "ShopKeeper_login_details.txt");

	for (int i = 0; i < count; i++)
	{
		if (username != o_username[i])
		{
			login_output_file << o_username[i] << " " << o_pass[i] << endl;
		}
	}

	login_output_file.close();
}
void Filing::store_updated_keepers(string username, Shop_Keeper* arr, int size)
{
	ofstream details_file(FILE_PATH + "ShopKeeper_details.csv");


	if (!details_file)
	{
		//print_error("\n\nERROR IN OPENING THE FILE: admin_details.csv or admin_login_details.txt\n\n");
	}
	else
	{
		for (int i = 0; i < size; i++)
		{
			details_file << arr[i].file_details();
		}

		details_file.close();
	}

	vector<string> o_username, o_pass;
	string un, pass;
	int count = 0;;

	ifstream login_input_file(FILE_PATH + "ShopKeeper_login_details.txt");

	while (!login_input_file.eof())
	{
		login_input_file >> un >> pass;
		o_username.push_back(un);
		o_pass.push_back(pass);
		count++;
	}
	login_input_file.close();

	ofstream login_output_file(FILE_PATH + "ShopKeeper_login_details.txt");

	for (int i = 0; i < count; i++)
	{
		if (username == o_username[i])
		{
			login_output_file << arr[i].file_logindetails();
		}
		else
		{
			login_output_file << o_username[i] << " " << o_pass[i] << endl;
		}
	}

	login_output_file.close();
}

bool Filing::find_customer(string username)
{
	ifstream login_file(FILE_PATH + "Customer_login_details.txt");

	bool found = false;
	string o_username, o_pass;

	// reads original username from the file
	while (!login_file.eof())
	{
		login_file >> o_username >> o_pass;
		if (username == o_username)
		{
			found = true;
			break;
		}

	}
	login_file.close();

	return found;
}
bool Filing::is_valid_login_customer(string username, string pass)
{
	ifstream login_file(FILE_PATH + "Customer_login_details.txt");

	bool logined = false;
	string o_username, o_pass;

	// reads original username from the file
	while (!login_file.eof())
	{
		login_file >> o_username >> o_pass;
		if (username == o_username)
		{
			pass = encrypt(username, pass);

			if (pass == o_pass)
			{
				logined = true;
				break;
			}
		}

	}
	login_file.close();

	return logined;
}

void Filing::initiate_all_customer(Customer*& customer_list, int& customer_count)
{
	ifstream details_file(FILE_PATH + "Customer_details.csv");
	int count = 0;
	string line, word;
	string details[7];
	//string o_username, fn, ln, em, cn, No, tprice;

	while (getline(details_file, line))
	{
		count = 0;
		stringstream str(line);

		while (getline(str, word, ','))
		{
			details[count++] = word;
		}
		//cout << details[0] << endl;
		//cout << admin_count << endl;
		expand<Customer>(customer_list, customer_count);

		customer_list[customer_count - 1].load_customer_data(details[0], details[1], details[2], details[3], details[4], details[5], details[6]);
	}

}

void Filing::add_new_customer(Customer* obj)
{
	ofstream details_file(FILE_PATH + "Customer_details.csv", ios::app);
	ofstream login_file(FILE_PATH + "Customer_login_details.txt", ios::app);

	if (!details_file || !login_file)
	{
		//print_error("\n\nERROR IN OPENING THE FILE: admin_details.csv or admin_login_details.txt\n\n");
	}
	else
	{
		details_file << obj->file_details();
		login_file << obj->file_logindetails();

		details_file.close();
		login_file.close();
	}
}
void Filing::store_deleted_customers(string username, Customer* arr, int size)
{
	ofstream details_file(FILE_PATH + "Customer_details.csv");


	if (!details_file)
	{
		print_error("\n\nERROR IN OPENING THE FILE: Customer_details.csv\n\n");
	}
	else
	{
		for (int i = 0; i < size; i++)
		{
			details_file << arr[i].file_details();
		}

		details_file.close();
	}

	vector<string> o_username, o_pass;
	string un, pass;
	int count = 0;;

	ifstream login_input_file(FILE_PATH + "Customer_login_details.txt");

	while (!login_input_file.eof())
	{
		login_input_file >> un >> pass;
		o_username.push_back(un);
		o_pass.push_back(pass);
		count++;
	}
	login_input_file.close();

	ofstream login_output_file(FILE_PATH + "Customer_login_details.txt");

	for (int i = 0; i < count; i++)
	{
		if (username != o_username[i])
		{
			login_output_file << o_username[i] << " " << o_pass[i] << endl;
		}
	}

	login_output_file.close();
}
void Filing::store_updated_customers(string username, Customer* arr, int size)
{
	ofstream details_file(FILE_PATH + "Customer_details.csv");


	if (!details_file)
	{
		//print_error("\n\nERROR IN OPENING THE FILE: admin_details.csv or admin_login_details.txt\n\n");
	}
	else
	{
		for (int i = 0; i < size; i++)
		{
			details_file << arr[i].file_details();
		}

		details_file.close();
	}

	vector<string> o_username, o_pass;
	string un, pass;
	int count = 0;;

	ifstream login_input_file(FILE_PATH + "Customer_login_details.txt");

	while (!login_input_file.eof())
	{
		login_input_file >> un >> pass;
		o_username.push_back(un);
		o_pass.push_back(pass);
		count++;
	}
	login_input_file.close();

	ofstream login_output_file(FILE_PATH + "Customer_login_details.txt");

	for (int i = 0; i < count; i++)
	{
		if (username == o_username[i])
		{
			login_output_file << arr[i].file_logindetails();
		}
		else
		{
			login_output_file << o_username[i] << " " << o_pass[i] << endl;
		}
	}

	login_output_file.close();
}

void Filing::initiate_all_Products(Product*& products_list, int& products_count)
{
	ifstream details_file(FILE_PATH + "product_details.csv");
	int count = 0;
	string line, word;
	string details[7];
	//string cname LbNo vID vName NoDoses price, quantity;

	while (getline(details_file, line))
	{
		count = 0;
		stringstream str(line);

		while (getline(str, word, ','))
		{
			details[count++] = word;
		}

		expand<Product>(products_list, products_count);

		products_list[products_count - 1].load_data(details[0], details[1], details[2]);
	}

}
void Filing::add_new_products(Product* obj)
{
	ofstream details_file(FILE_PATH + "product_details.csv", ios::app);

	if (!details_file)
	{
		//print_error("\n\nERROR IN OPENING THE FILE: admin_details.csv or admin_login_details.txt\n\n");
	}
	else
	{
		details_file << obj->file_details();

		details_file.close();
	}
}
void Filing::store_Products(Product* arr, int size)
{
	ofstream details_file(FILE_PATH + "product_details.csv");


	if (!details_file)
	{
		//print_error("\n\nERROR IN OPENING THE FILE: admin_details.csv or admin_login_details.txt\n\n");
	}
	else
	{
		for (int i = 0; i < size; i++)
		{
			details_file << arr[i].file_details();
		}
		details_file.close();
	}
}

//------------------------ CUSTOMER DEFINATIONS------------------------------------------------------------------
Customer::Customer(string un, string fn, string ln, string em, string cn, string No) : person(un, fn, ln, em, cn, No) {}
void Customer::customerOutput()
{
	output();

}
void Customer::load_customer_data(string un, string fn, string ln, string em, string cn, string No, string tprice)
{
	load_person_data(un, fn, ln, em, cn, No);

}
void Customer::input_login_details()
{
	string un, un_num, p;
	bool correct_input = false;

	while (!correct_input)
	{
		try
		{
			un = "CU";
			cout << "Enter the username: CU";
			cin >> un_num;

			if (!regex_match(un_num, valid_user_num))
			{
				throw invalid_username();
			}

			un += un_num; // concats the digits with "AD"

			if (Filing::find_customer(un))
			{
				throw username_exists();
			}

			cout << "\nEnter the password";
			cin >> p;

			if (!is_valid_password(p))
			{
				throw invalid_password();
			}

			correct_input = true;
		}
		catch (const exception& e)
		{
			SetConsoleTextAttribute(h, 252);
			print_spaces();
			cout << "[!] Exception: " << e.what() << endl;
			SetConsoleTextAttribute(h, 240);
		}
	}

	username = un;
	pass = encrypt(un, p);


}

//------------------------ PRODUCT DEFINATIONS------------------------------------------------------------------

void Product::ProductInput() //admin can add companies
{
	cout << "Enter product Category: ";
	cin >> category;
	cout << "Enter Product name: ";
	cin >> ProductName;
	cout << "Enter Product Quantity: ";
	cin >> ProductQuantity;

}

void Product::ProductOutput() //review company details
{
	cout << "Product Name: " << ProductName << endl;
	cout << "Product Category: " << category << endl;
	cout << " Product Qauntity: " << ProductQuantity << endl;
}

string Product::file_details()
{
	return ProductName + "," + category + "," + ProductQuantity + ",\n";
}

bool Product::compare_ProductName(string n)
{
	return n == ProductName;
}

void Product::load_data(string cname, string cate, string quantity)
{
	ProductName = cname;
	category = cate;
	ProductQuantity = quantity;
}
