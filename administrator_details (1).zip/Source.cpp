#pragma warning(disable : 4996)
#include <iostream>
#include <iomanip>
#include <conio.h>
#include <string>
#include <exception>	
#include <windows.h>
#include <chrono>
#include <thread>
#include "Header.h"
using namespace std;


void heading(string msg);
void print_login(string username, string pass, int count);

void login_page(string& username, string& pass);
void super_admin_page(string username);

void admin_page(string username);

void admin1_page(string username);

void login_process(string username, string pass);

int main()
{
	char x;
	string username, pass;
	bool loop = true;
	char choice;

	Filing::login_admin("AD11220");

	system("cls");
	system("Color F0");
	while (loop)
	{
		username = pass = "";

		system("cls");
		heading("MAIN MENU");

		print_spaces();
		cout << "1. Admin Login\n";
		print_spaces();
		cout << "2. Exit\n";

		print_spaces();
		cout << "ENTER ANY OPTION";
		choice = _getch();

		switch (choice)
		{
		case '1':
			system("cls");
			login_page(username, pass);
			login_process(username, pass);
			break;

		case '2':
			print_error("\n\n[!] EXITING PROGRAM [!]\n");

			loop = false;
			break;

		default:
			print_error("\n\n[!] INVALID INPUT [!]\n");
			break;
		}

		cout << "\n\nPRESS ANY KEY TO CONTINUE";
		_getch();

	}

	system("pause");
	return 0;
}

void heading(string msg)
{
	system("cls");
	cout << "STORE";
	print_spaces();
	cout << setfill('-') << setw(10) << "";
	cout << msg;
	cout << setfill('-') << setw(10) << "\n\n";
}
void print_login(string username, string pass, int count)
{
	system("cls");
	cout << "STORE";

	print_spaces();
	cout << setfill('-') << setw(10) << "";
	cout << "LOGIN PAGE";
	cout << setfill('-') << setw(10) << "\n\n";


	print_spaces();
	cout << "Username: ";
	SetConsoleTextAttribute(h, 241);
	cout << username;
	SetConsoleTextAttribute(h, 240);

	cout << "\n";
	print_spaces();
	cout << "Password: ";
	for (int i = 0; i < count; i++)
	{
		SetConsoleTextAttribute(h, 241);
		cout << "*";
		SetConsoleTextAttribute(h, 240);
	}
}

void login_page(string& username, string& pass)
{
	char pass_char;
	int count = 0;
	cout << "STORE";

	print_spaces();
	cout << setfill('-') << setw(10) << "";
	cout << "LOGIN PAGE";
	cout << setfill('-') << setw(10) << "\n\n";


	print_spaces();
	try
	{
		cout << "Username: ";
		SetConsoleTextAttribute(h, 241);
		cin >> username;
		SetConsoleTextAttribute(h, 240);

		if (!is_valid_username(username))
		{
			throw invalid_username();
		}

		print_spaces();
		cout << "Password: ";
		pass_char = _getch();
		while (pass_char != '\r')
		{
			cout << pass_char;
			pass.push_back(pass_char);
			count++;
			print_login(username, pass, count);
			pass_char = _getch();
		}

		if (!is_valid_password(pass))
		{
			throw invalid_password();
		}
	}
	catch (const exception& e)
	{
		SetConsoleTextAttribute(h, 252);
		print_spaces();
		cout << "[!] Exception: " << e.what() << endl;
		SetConsoleTextAttribute(h, 240);
	}


	cout << "\n" << pass << endl;

}
void super_admin_page(string username)
{
	bool loop = true;
	char choice;
	Administrator* SA = Filing::login_admin(username);


	while (loop)
	{
		heading("ADMINISTRATOR MENU");

		print_spaces();
		cout << "1. Create Shop Keeper\n";
		print_spaces();
		cout << "2. Remove Shop Keeper\n";
		print_spaces();
		cout << "3. Update Shop Keeper\n";
		print_spaces();
		cout << "4. Display Shop Keepers\n";
		print_spaces();
		cout << "5. Create Customer\n";
		print_spaces();
		cout << "6. Remove Customer\n";
		print_spaces();
		cout << "7. Update Customer\n";
		print_spaces();
		cout << "8. Display Customer\n";
		print_spaces();
		cout << "9. Add Product\n";
		print_spaces();
		cout << "0. Remove Product\n";
		print_spaces();
		cout << "a. Display Product\n";
		print_spaces();
		cout << "b. Exit\n";
		print_spaces();
		cout << "ENTER ANY OPTION";
		choice = _getch();

		switch (choice)
		{
		case '1':
			heading("CREATE SHOP KEEPER");

			SA->create_keeper();
			break;

		case '2':
			heading("REMOVE SHOP KEEPER");

			SA->delete_keeper();
			break;


		case '3':
			heading("UPDATE SHOP KEEPER");

			SA->update_keeper();
			break;

		case '4':
			heading("DISPLAY SHOP KEEPERs");

			SA->display_keeper();
			break;


		case '5':
			heading("CREATE CUSTOMER");

			SA->create_customer();
			break;

		case '6':
			heading("REMOVE CUSTOMER");

			SA->delete_customer();
			break;

		case '7':
			heading("UPDATE CUSTOMER");

			SA->update_customer();
			break;

		case '8':
			heading("DISPLAY CUSTOMER");

			SA->display_customer();
			break;


		case '9':
			heading("ADD PRODUCT");

			SA->add_product_admin();
			break;

		case '0':
			heading("REMOVE PRODUCT");

			SA->delete_product_admin();
			break;

		case 'a':
			heading("DISPLAY PRODUCT");

			SA->display_product_admin();
			break;

		case 'b':
			print_error("\n\n[!] EXITING SUPER ADMIN MENU [!]\n");

			loop = false;
			break;

		default:
			print_error("\n\n[!] INVALID INPUT [!]\n");
			break;
		}

		cout << "\n\nPRESS ANY KEY TO CONTINUE";
		_getch();

	}
}

void admin_page(string username)
{
	bool loop = true;
	char choice;
	Shop_Keeper* KEEPER = nullptr;
	KEEPER = Administrator::Keeper_obj(username);
	while (loop)
	{
		heading("SHOP KEEPER MENU");

		print_spaces();
		cout << "1. Add Product\n";
		print_spaces();
		cout << "2. Remove Product\n";
		print_spaces();
		cout << "3. Display Product\n";
		print_spaces();
		cout << "4. Exit\n";

		print_spaces();
		cout << "ENTER ANY OPTION";
		choice = _getch();

		switch (choice)
		{
		case '1':
			heading("ADD COMPANY");

			KEEPER->add_product();
			break;

		case '2':
			heading("REMOVE COMPANY");

			KEEPER->delete_product();
			break;


		case '3':
			heading("COMPANIES");

			KEEPER->display_product();
			break;

		case '4':
			print_error("\n\n[!] EXITING ADMIN MENU [!]\n");

			loop = false;
			break;

		default:
			print_error("\n\n[!] INVALID INPUT [!]\n");
			break;
		}

		cout << "\n\nPRESS ANY KEY TO CONTINUE";
		_getch();

	}


}

void admin1_page(string username)
{
	bool loop = true;
	char choice;
	Customer* CUSTOMER = nullptr;
	CUSTOMER = Administrator::customer_obj(username);
	while (loop)
	{
		heading("SHOP KEEPER MENU");

		print_spaces();
		cout << "1. Add Product\n";
		print_spaces();
		cout << "2. Exit\n";

		print_spaces();
		cout << "ENTER ANY OPTION";
		choice = _getch();

		switch (choice)
		{
		case '1':
			heading("ADD COMPANY");

			cout << "OUT of ORDER";
			break;

		case '2':
			print_error("\n\n[!] EXITING ADMIN MENU [!]\n");

			loop = false;
			break;

		default:
			print_error("\n\n[!] INVALID INPUT [!]\n");
			break;
		}

		cout << "\n\nPRESS ANY KEY TO CONTINUE";
		_getch();

	}


}

void login_process(string username, string pass)
{
	string modes[3] = { "AD", "SK", "CU" };
	string mode = username.substr(0, 2);
	try
	{
		if (mode == modes[0]) // Super Admin
		{
			if (Filing::find_admin(username))
			{
				if (Filing::is_valid_login_admin(username, pass))
				{
					super_admin_page(username);
				}
				else
				{
					throw wrong_password();
				}
			}
			else
			{
				throw unregistered_username();
			}
		}
		else if (mode == modes[1]) // Admin
		{
			if (Filing::find_keeper(username))
			{
				if (Filing::is_valid_login_keeper(username, pass))
				{
					admin_page(username);
				}
				else
				{
					throw wrong_password();
				}
			}
			else
			{
				throw unregistered_username();
			}
		}
		else if (mode == modes[2]) // Front Desk Officer
		{
			if (Filing::find_customer(username))
			{
				if (Filing::is_valid_login_customer(username, pass))
				{
					admin1_page(username);
				}
				else
				{
					throw wrong_password();
				}
			}
			else
			{
				throw unregistered_username();
			}
		}
	}
	catch (const exception& e)
	{
		SetConsoleTextAttribute(h, 252);
		print_spaces();
		cout << "[!] Exception: " << e.what() << endl;
		SetConsoleTextAttribute(h, 240);
	}

}